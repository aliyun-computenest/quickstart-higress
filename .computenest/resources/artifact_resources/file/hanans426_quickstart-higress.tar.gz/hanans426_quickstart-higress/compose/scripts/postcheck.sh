#! /bin/bash

echo "All good!"